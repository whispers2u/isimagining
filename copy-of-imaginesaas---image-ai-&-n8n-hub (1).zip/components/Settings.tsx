
import React from 'react';
import { UserConfig } from '../types';

interface SettingsProps {
  config: UserConfig;
  setConfig: React.Dispatch<React.SetStateAction<UserConfig>>;
}

const Settings: React.FC<SettingsProps> = ({ config, setConfig }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn pb-20">
      <header>
        <h2 className="text-3xl font-bold mb-2">Backend n8n Production</h2>
        <p className="text-gray-400">Gérez la connexion entre cette interface et votre serveur d'automatisation.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <section className="bg-[#151921] border border-gray-800 rounded-3xl p-8 shadow-xl">
            <h3 className="font-semibold text-lg mb-6">Endpoint Webhook</h3>
            
            <div className="space-y-4">
              <label className="block text-sm font-medium text-gray-400">URL de Production</label>
              <div className="relative">
                <i className="fas fa-link absolute left-5 top-1/2 -translate-y-1/2 text-gray-500"></i>
                <input
                  type="text"
                  value={config.n8nWebhookUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, n8nWebhookUrl: e.target.value }))}
                  placeholder="https://votre-n8n.com/webhook/generate-image"
                  className="w-full bg-[#0b0e14] border border-gray-800 rounded-2xl pl-12 pr-5 py-5 text-sm focus:ring-2 focus:ring-indigo-600 outline-none transition-all shadow-inner"
                />
              </div>
              <div className="flex gap-3 p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl">
                <i className="fas fa-info-circle text-indigo-400 mt-0.5"></i>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  L'application enverra un <b>POST JSON</b> contenant <code className="text-indigo-300">prompt</code> et <code className="text-indigo-300">aspectRatio</code>. Votre workflow doit retourner une URL d'image directe ou un JSON incluant le lien de résultat.
                </p>
              </div>
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="font-bold text-lg mb-4">Architecture Native</h3>
              <p className="text-sm opacity-90 leading-relaxed">
                Cette interface est optimisée pour les déploiements n8n. Elle supporte nativement les retours d'URLs signées (AWS S3, Scaleway) et les formats Base64.
              </p>
            </div>
            <i className="fas fa-microchip absolute -right-4 -bottom-4 text-white/5 text-9xl"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
