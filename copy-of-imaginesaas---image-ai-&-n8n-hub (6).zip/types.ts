
export type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
  provider: 'n8n';
  settings: {
    aspectRatio: AspectRatio;
  };
}

export interface UserConfig {
  n8nWebhookUrl: string;
  n8nLoginWebhookUrl: string;
  n8nSignupWebhookUrl: string;
}
