
// Ce service a été désactivé pour privilégier l'architecture n8n native.
export const refinePrompt = async (userPrompt: string): Promise<string> => {
  return userPrompt;
};

export const generateImageWithGemini = async (prompt: string, aspectRatio: string): Promise<string> => {
  throw new Error("Moteur Gemini désactivé. Utilisez le workflow n8n.");
};
