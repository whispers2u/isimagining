
import React from 'react';
import { UserConfig } from '../types';

interface SettingsProps {
  config: UserConfig;
  setConfig: React.Dispatch<React.SetStateAction<UserConfig>>;
}

const Settings: React.FC<SettingsProps> = ({ config, setConfig }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn pb-20">
      <header>
        <h2 className="text-3xl font-bold mb-2 text-white">Configuration</h2>
        <p className="text-gray-400 text-sm">Ajustez les URLs de vos pipelines n8n si nécessaire.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <section className="bg-[#151921] border border-gray-800 rounded-3xl p-6 md:p-8 shadow-xl">
            <h3 className="font-semibold text-lg mb-6 flex items-center gap-3 text-white">
              <i className="fas fa-network-wired text-indigo-500"></i>
              Pipelines de Génération & Auth
            </h3>
            
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest ml-1">Webhook Génération d'Image (POST)</label>
                <input
                  type="text"
                  value={config.n8nWebhookUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, n8nWebhookUrl: e.target.value }))}
                  placeholder="https://votre-n8n.com/webhook/..."
                  className="w-full bg-[#0b0e14] border border-gray-800 rounded-2xl px-5 py-4 text-sm text-white focus:ring-2 focus:ring-indigo-600 outline-none transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest ml-1">Webhook Connexion (Login)</label>
                <input
                  type="text"
                  value={config.n8nLoginWebhookUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, n8nLoginWebhookUrl: e.target.value }))}
                  placeholder="https://votre-n8n.com/webhook/login"
                  className="w-full bg-[#0b0e14] border border-gray-800 rounded-2xl px-5 py-4 text-sm text-white focus:ring-2 focus:ring-indigo-600 outline-none transition-all"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest ml-1">Webhook Inscription (Signup)</label>
                <input
                  type="text"
                  value={config.n8nSignupWebhookUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, n8nSignupWebhookUrl: e.target.value }))}
                  placeholder="https://votre-n8n.com/webhook/signup"
                  className="w-full bg-[#0b0e14] border border-gray-800 rounded-2xl px-5 py-4 text-sm text-white focus:ring-2 focus:ring-indigo-600 outline-none transition-all"
                />
              </div>

              <p className="text-[10px] text-gray-500 italic">
                Configurez ici les points d'entrée vers vos workflows d'automatisation n8n.
              </p>
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-600/10 border border-indigo-600/20 rounded-3xl p-6">
            <h4 className="font-bold text-sm text-indigo-400 mb-3 uppercase tracking-wider">État du Service</h4>
            <div className="flex items-center gap-3 text-xs text-gray-400">
               <span className="w-2 h-2 rounded-full bg-green-500"></span>
               Système prêt
            </div>
            <p className="text-[10px] text-gray-500 mt-4 leading-relaxed">
              L'application utilise votre navigateur pour stocker l'historique et la configuration localement.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
