
import React, { useState } from 'react';
import { AspectRatio, UserConfig } from '../types';

interface PromptPanelProps {
  onGenerate: (prompt: string, aspectRatio: AspectRatio) => void;
  isLoading: boolean;
  config: UserConfig;
  setConfig: React.Dispatch<React.SetStateAction<UserConfig>>;
}

const PromptPanel: React.FC<PromptPanelProps> = ({ onGenerate, isLoading, config }) => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');

  const ratios: { value: AspectRatio; label: string; icon: string }[] = [
    { value: '1:1', label: '1:1', icon: 'fa-square' },
    { value: '16:9', label: '16:9', icon: 'fa-rectangle-list rotate-90' },
    { value: '9:16', label: '9:16', icon: 'fa-rectangle-list' },
    { value: '4:3', label: '4:3', icon: 'fa-image' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;
    onGenerate(prompt, aspectRatio);
  };

  return (
    <div className="bg-[#151921] border border-gray-800 rounded-2xl md:rounded-3xl p-4 md:p-6 shadow-2xl relative">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="relative">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2 px-1">Concept visuel</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Décrivez votre image..."
            className="w-full h-32 md:h-40 bg-[#0b0e14] border border-gray-800 rounded-xl md:rounded-2xl p-4 md:p-5 text-gray-100 placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-600 transition-all resize-none text-sm md:text-base"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-1">Format</label>
          <div className="grid grid-cols-4 gap-2">
            {ratios.map((ratio) => (
              <button
                key={ratio.value}
                type="button"
                onClick={() => setAspectRatio(ratio.value)}
                className={`flex flex-col items-center justify-center py-3 px-1 rounded-xl border transition-all ${
                  aspectRatio === ratio.value
                    ? 'bg-indigo-600/10 border-indigo-600 text-indigo-400 shadow-[0_0_10px_rgba(79,70,229,0.1)]'
                    : 'bg-[#0b0e14] border-gray-800 text-gray-500'
                }`}
              >
                <i className={`fas ${ratio.icon} text-sm mb-1`}></i>
                <span className="text-[10px] font-bold">{ratio.label}</span>
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading || !prompt.trim()}
          className={`w-full py-4 md:py-5 rounded-xl md:rounded-2xl font-bold flex items-center justify-center transition-all ${
            isLoading || !prompt.trim()
              ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xl active:scale-[0.98]'
          }`}
        >
          {isLoading ? (
            <div className="flex items-center gap-3">
              <i className="fas fa-spinner fa-spin"></i>
              <span className="text-sm md:text-base">Génération...</span>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <i className="fas fa-bolt"></i>
              <span className="tracking-tight text-sm md:text-base uppercase">Générer</span>
            </div>
          )}
        </button>

        {!config.n8nWebhookUrl && (
          <p className="text-center text-[10px] text-red-400">
            <i className="fas fa-exclamation-triangle mr-1"></i> Webhook non configuré
          </p>
        )}
      </form>
    </div>
  );
};

export default PromptPanel;
