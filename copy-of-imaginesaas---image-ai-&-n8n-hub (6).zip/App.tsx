
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import PromptPanel from './components/PromptPanel';
import Settings from './components/Settings';
import { generateImageWithN8n } from './services/n8nService';
import { GeneratedImage, UserConfig, AspectRatio } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('studio');
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<GeneratedImage[]>([]);
  const [lastImage, setLastImage] = useState<GeneratedImage | null>(null);
  const [loadingStep, setLoadingStep] = useState('');
  
  const DEFAULT_WEBHOOK = "https://automation.autec.online/webhook/generate-image";
  const DEFAULT_LOGIN = "https://automation.autec.online/webhook/login";
  const DEFAULT_SIGNUP = "https://automation.autec.online/webhook/signup";

  const [config, setConfig] = useState<UserConfig>(() => {
    const savedConfig = localStorage.getItem('imagine_config');
    if (savedConfig) {
      const parsed = JSON.parse(savedConfig);
      return {
        n8nWebhookUrl: parsed.n8nWebhookUrl || DEFAULT_WEBHOOK,
        n8nLoginWebhookUrl: parsed.n8nLoginWebhookUrl || DEFAULT_LOGIN,
        n8nSignupWebhookUrl: parsed.n8nSignupWebhookUrl || DEFAULT_SIGNUP,
      };
    }
    return {
      n8nWebhookUrl: DEFAULT_WEBHOOK,
      n8nLoginWebhookUrl: DEFAULT_LOGIN,
      n8nSignupWebhookUrl: DEFAULT_SIGNUP,
    };
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('imagine_history');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
  }, []);

  useEffect(() => {
    localStorage.setItem('imagine_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('imagine_config', JSON.stringify(config));
  }, [config]);

  const handleGenerate = async (prompt: string, aspectRatio: AspectRatio) => {
    if (!config.n8nWebhookUrl) {
      alert("Veuillez configurer l'URL du Webhook dans les réglages.");
      setActiveTab('settings');
      return;
    }

    setIsLoading(true);
    setLoadingStep('Initialisation...');
    
    let stepIndex = 0;
    const steps = ['Analyse...', 'Workflow n8n...', 'Traitement...', 'Finalisation...'];
    const progressInterval = setInterval(() => {
      setLoadingStep(steps[stepIndex % steps.length]);
      stepIndex++;
    }, 3000);

    try {
      const imageUrl = await generateImageWithN8n(config.n8nWebhookUrl, prompt, aspectRatio);
      const newImage: GeneratedImage = {
        id: Math.random().toString(36).substr(2, 9),
        url: imageUrl,
        prompt,
        timestamp: Date.now(),
        provider: 'n8n',
        settings: { aspectRatio },
      };
      setLastImage(newImage);
      setHistory((prev) => [newImage, ...prev]);
    } catch (error: any) {
      alert(`Erreur n8n : ${error.message}`);
    } finally {
      setIsLoading(false);
      clearInterval(progressInterval);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'studio':
        return (
          <div className="flex flex-col lg:grid lg:grid-cols-12 gap-6 md:gap-8 h-full pb-20 md:pb-0">
            <div className="lg:col-span-5 flex flex-col gap-6">
              <header className="mb-2">
                <div className="flex items-center gap-2 text-indigo-400 text-[10px] font-bold uppercase tracking-widest mb-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
                  n8n Engine Actif
                </div>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">Studio Créatif</h1>
                <p className="text-gray-400 mt-1 text-sm">Générez vos visuels via votre pipeline d'automatisation.</p>
              </header>
              
              <PromptPanel onGenerate={handleGenerate} isLoading={isLoading} config={config} setConfig={setConfig} />
              
              <div className="hidden lg:block mt-auto">
                <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">Récemment généré</h3>
                <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
                  {history.slice(0, 5).map(img => (
                    <button key={img.id} onClick={() => setLastImage(img)} className="w-14 h-14 rounded-xl overflow-hidden shrink-0 border border-gray-800 hover:border-indigo-500 transition-all bg-gray-900 group">
                      <img src={img.url} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 flex flex-col min-h-[400px] md:min-h-[550px]">
              <div className="flex-1 bg-[#151921] border border-gray-800 rounded-3xl md:rounded-[2.5rem] overflow-hidden relative group shadow-2xl flex items-center justify-center">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center text-center p-8 w-full h-full bg-[#0d1016]/50 backdrop-blur-sm">
                    <div className="relative w-20 h-20 md:w-32 md:h-32 mb-8">
                      <div className="absolute inset-0 bg-indigo-600/20 blur-3xl rounded-full animate-pulse"></div>
                      <div className="absolute inset-0 border-2 md:border-4 border-transparent border-t-indigo-500 rounded-full animate-spin"></div>
                      <i className="fas fa-bolt text-indigo-400 text-xl md:text-3xl absolute inset-0 flex items-center justify-center animate-pulse"></i>
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold text-white animate-pulse">{loadingStep}</h3>
                  </div>
                ) : lastImage ? (
                  <div className="relative w-full h-full p-2 md:p-4 flex items-center justify-center bg-[#0d1016]">
                    <img src={lastImage.url} alt={lastImage.prompt} className="max-w-full max-h-full object-contain rounded-xl md:rounded-2xl animate-fadeIn" />
                    <a href={lastImage.url} target="_blank" rel="noreferrer" className="absolute bottom-4 right-4 bg-black/60 hover:bg-indigo-600 p-3 rounded-xl text-white backdrop-blur-md border border-white/10 transition-all text-[10px] font-bold">
                       <i className="fas fa-expand mr-2"></i> VOIR SOURCE
                    </a>
                  </div>
                ) : (
                  <div className="text-center p-8 opacity-40">
                    <i className="fas fa-layer-group text-indigo-500 text-4xl mb-6"></i>
                    <h2 className="text-lg font-bold uppercase tracking-widest text-gray-500">En attente de création</h2>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      case 'gallery':
        return (
          <div className="space-y-6 md:space-y-8 animate-fadeIn pb-24 md:pb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-white">Ma Galerie</h2>
            {history.length === 0 ? <p className="text-gray-600 text-sm">Votre galerie locale est vide.</p> : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 md:gap-6">
                {history.map((img) => (
                  <button key={img.id} onClick={() => { setLastImage(img); setActiveTab('studio'); }} className="aspect-square rounded-xl md:rounded-[1.5rem] overflow-hidden border border-gray-800 hover:border-indigo-500 transition-all shadow-md">
                    <img src={img.url} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      case 'settings': 
        return <div className="pb-24 md:pb-0"><Settings config={config} setConfig={setConfig} /></div>;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden bg-[#0b0e14]">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 overflow-y-auto p-4 md:p-10 relative custom-scrollbar">
        <div className="max-w-7xl mx-auto h-full relative z-10">
          {renderContent()}
        </div>
        <div className="fixed top-0 right-0 w-[50%] h-[50%] bg-indigo-600/5 blur-[120px] rounded-full pointer-events-none -z-10"></div>
      </main>
    </div>
  );
};

export default App;
