
import { AspectRatio, User } from "../types";

/**
 * Service pour la génération d'image via n8n
 */
export const generateImageWithN8n = async (
  webhookUrl: string, 
  prompt: string, 
  aspectRatio: AspectRatio
): Promise<string> => {
  if (!webhookUrl) {
    throw new Error("URL Webhook n8n non configurée.");
  }

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        aspectRatio,
        timestamp: new Date().toISOString()
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erreur n8n (${response.status}): ${errorText}`);
    }

    const textResponse = await response.text();
    
    // Tentative d'extraction de l'URL brute (si n8n renvoie juste un string)
    const possibleUrl = textResponse.trim().replace(/^["']|["']$/g, '');
    if (possibleUrl.startsWith('http')) return possibleUrl;

    // Tentative d'analyse JSON
    const data = JSON.parse(textResponse);
    let foundUrl = "";

    const findImageLink = (obj: any): void => {
      if (!obj || foundUrl) return;
      if (typeof obj === 'string') {
        const s = obj.trim();
        if (s.startsWith('http') && (s.includes('.png') || s.includes('.jpg') || s.includes('.jpeg') || s.includes('X-Amz-Signature'))) {
          foundUrl = s;
        }
        return;
      }
      if (Array.isArray(obj)) {
        for (const item of obj) findImageLink(item);
        return;
      }
      if (typeof obj === 'object') {
        const priorityKeys = ['result_url', 'imageUrl', 'url', 'result', 'data', 'output'];
        for (const key of priorityKeys) {
          const val = obj[key];
          if (typeof val === 'string' && val.startsWith('http')) {
            foundUrl = val;
            return;
          }
        }
        for (const key in obj) findImageLink(obj[key]);
      }
    };

    findImageLink(data);
    if (foundUrl) return foundUrl;

    throw new Error("Impossible de trouver une URL d'image dans la réponse.");
  } catch (error: any) {
    throw new Error(error.message || "Erreur de connexion au pipeline n8n.");
  }
};

/**
 * Service pour l'authentification via n8n
 */
export const authenticateWithN8n = async (
  webhookUrl: string, 
  credentials: any, 
  mode: 'login' | 'signup'
): Promise<User> => {
  if (!webhookUrl) {
    throw new Error(`URL Webhook n8n (${mode}) non configurée.`);
  }

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...credentials,
        mode,
        timestamp: new Date().toISOString()
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erreur authentification (${response.status}): ${errorText}`);
    }

    const data = await response.json();
    
    // Tentative d'extraction de l'utilisateur de la réponse JSON
    const user = data.user || data;

    if (!user || !user.id) {
      throw new Error("Réponse d'authentification invalide : ID utilisateur manquant.");
    }

    return {
      id: user.id.toString(),
      name: user.name || credentials.name || 'Utilisateur',
      email: user.email || credentials.email,
      avatar: user.avatar
    };
  } catch (error: any) {
    throw new Error(error.message || "Erreur de connexion au service d'authentification.");
  }
};
