
import React, { useState } from 'react';
import { User, UserConfig } from '../types';
import { authenticateWithN8n } from '../services/n8nService';

interface AuthScreenProps {
  onLogin: (user: User) => void;
  config: UserConfig;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, config }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const webhookUrl = isLogin ? config.n8nLoginWebhookUrl : config.n8nSignupWebhookUrl;
      const user = await authenticateWithN8n(
        webhookUrl, 
        { email, password, name }, 
        isLogin ? 'login' : 'signup'
      );
      
      localStorage.setItem('imagine_auth_token', `n8n_session_${user.id}_${Date.now()}`);
      localStorage.setItem('imagine_user', JSON.stringify(user));
      
      onLogin(user);
    } catch (err: any) {
      setError(err.message || "Impossible de joindre le serveur d'authentification.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#0b0e14] p-4 overflow-y-auto">
      <div className="absolute top-[-10%] right-[-5%] w-full h-full bg-indigo-600/10 blur-[120px] rounded-full"></div>

      <div className="relative w-full max-w-md py-8 animate-fadeIn">
        <div className="bg-[#151921]/90 backdrop-blur-2xl border border-white/10 rounded-3xl md:rounded-[2.5rem] p-6 md:p-10 shadow-2xl">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 md:w-16 md:h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-4 md:mb-6 shadow-xl shadow-indigo-600/20">
              <i className="fas fa-bolt text-white text-2xl md:text-3xl"></i>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white mb-2 text-center">ImagineSaaS</h1>
            <p className="text-gray-400 text-xs md:text-sm font-medium text-center px-4">
              {isLogin ? 'Le futur de l\'IA automatisée.' : 'Rejoignez le studio créatif.'}
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-[10px] md:text-xs font-medium flex items-center gap-3">
              <i className="fas fa-exclamation-triangle"></i>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 md:space-y-5">
            {!isLogin && (
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Nom</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full bg-black/40 border border-white/5 rounded-xl px-5 py-3 md:py-4 text-sm focus:ring-2 focus:ring-indigo-600 outline-none"
                />
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nom@exemple.com"
                className="w-full bg-black/40 border border-white/5 rounded-xl px-5 py-3 md:py-4 text-sm focus:ring-2 focus:ring-indigo-600 outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Mot de passe</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-black/40 border border-white/5 rounded-xl px-5 py-3 md:py-4 text-sm focus:ring-2 focus:ring-indigo-600 outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-indigo-600 hover:bg-indigo-500 py-3.5 md:py-4 rounded-xl md:rounded-2xl font-bold text-white shadow-xl shadow-indigo-600/20 transition-all active:scale-[0.98] mt-2 flex items-center justify-center gap-3"
            >
              {isLoading ? (
                <i className="fas fa-circle-notch fa-spin"></i>
              ) : (
                <span>{isLogin ? 'Se connecter' : 'Créer un compte'}</span>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button
              onClick={() => {setIsLogin(!isLogin); setError(null);}}
              className="text-xs md:text-sm text-indigo-400 font-bold hover:text-indigo-300 transition-colors"
            >
              {isLogin ? "Pas de compte ? S'inscrire" : "Déjà membre ? Se connecter"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
