
import React from 'react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'studio', icon: 'fa-wand-magic-sparkles', label: 'Studio' },
    { id: 'gallery', icon: 'fa-images', label: 'Galerie' },
    { id: 'settings', icon: 'fa-cog', label: 'Réglages' },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 bg-[#0b0e14] border-r border-gray-800 flex-col py-6 px-4 shrink-0 h-screen sticky top-0">
        <div className="flex items-center gap-3 px-2 mb-10">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-indigo-600/20">
            <i className="fas fa-bolt text-white text-xl"></i>
          </div>
          <span className="font-black text-xl tracking-tight text-white">ImagineSaaS</span>
        </div>

        <nav className="flex-1 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all ${
                activeTab === item.id 
                  ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-600/20 shadow-inner' 
                  : 'text-gray-500 hover:bg-gray-800/50 hover:text-gray-200 border border-transparent'
              }`}
            >
              <i className={`fas ${item.icon} w-6 text-center text-lg`}></i>
              <span className="font-bold tracking-tight">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-gray-800/50 flex flex-col gap-2">
           <div className="px-4 py-2 text-[10px] font-bold text-gray-600 uppercase tracking-[0.2em] text-center">
              Powered by n8n
           </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0d1016]/95 backdrop-blur-xl border-t border-white/10 z-[100] px-4 py-3 pb-safe-area-inset-bottom flex justify-around items-center">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 p-2 transition-all ${
              activeTab === item.id ? 'text-indigo-400 scale-110' : 'text-gray-500'
            }`}
          >
            <i className={`fas ${item.icon} text-lg`}></i>
            <span className="text-[10px] font-bold uppercase tracking-wider">{item.label}</span>
          </button>
        ))}
      </nav>
    </>
  );
};

export default Sidebar;
